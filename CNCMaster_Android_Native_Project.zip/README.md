# CNC MASTER – Learn by Levels
Designed & Developed by Sai Prakash

## Complete Native Android Project (Kotlin + Jetpack Compose Material 3)

### How to Build and Run in Android Studio:
1. Open Android Studio.
2. Choose File > Open and select this unzipped folder.
3. Allow Gradle to synchronize dependencies (compileSdk 34, AGP 8.4+, Kotlin 2.0).
4. Connect an Android phone via USB (with USB Debugging enabled in Developer Options) or start an AVD emulator.
5. Click Run > Run app (or press Shift + F10) to install and launch directly on your phone!

### How to Build a Standalone APK file:
1. In Android Studio, go to top menu: Build > Build Bundle(s) / APK(s) > Build APK(s).
2. When the build finishes, click locate in the popup (the APK will be generated at app/build/outputs/apk/debug/app-debug.apk).
3. Transfer this app-debug.apk file to your Android phone and tap to install!

Category: Education & Engineering
Architecture: 100% Offline, Jetpack Compose Material 3, Kotlin DSL
