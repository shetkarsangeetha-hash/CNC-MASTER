package com.saiprakash.cncmaster

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * CNC MASTER – Learn by Levels
 * Designed & Developed by Sai Prakash
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    background = Color(0xFF070B14),
                    surface = Color(0xFF0F172A),
                    primary = Color(0xFF00E5FF),
                    secondary = Color(0xFF1E88E5)
                )
            ) {
                var selectedTab by remember { mutableIntStateOf(0) }
                var language by remember { mutableStateOf("en") }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = Color(0xFF070B14),
                    topBar = {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF0F172A))
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "CNC MASTER",
                                    color = Color(0xFF00E5FF),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp
                                )
                                Text(
                                    text = "Learn by Levels",
                                    color = Color(0xFF94A3B8),
                                    fontSize = 11.sp
                                )
                            }
                            Button(
                                onClick = { language = if (language == "en") "te" else "en" },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(if (language == "en") "English" else "తెలుగు", color = Color(0xFF00E5FF))
                            }
                        }
                    },
                    bottomBar = {
                        NavigationBar(containerColor = Color(0xFF0F172A)) {
                            val tabs = listOf("Home", "Learn", "3D Lathe", "Codes", "Profile")
                            tabs.forEachIndexed { index, title ->
                                NavigationBarItem(
                                    selected = selectedTab == index,
                                    onClick = { selectedTab = index },
                                    label = { Text(title, fontSize = 10.sp) },
                                    icon = {
                                        Box(
                                            modifier = Modifier
                                                .size(8.dp)
                                                .background(
                                                    if (selectedTab == index) Color(0xFF00E5FF) else Color.Gray,
                                                    RoundedCornerShape(4.dp)
                                                )
                                        )
                                    }
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .padding(16.dp)
                    ) {
                        when (selectedTab) {
                            0 -> HomeView(language)
                            1 -> LearnView(language)
                            2 -> LatheSimulatorView()
                            3 -> CodeMasterView()
                            4 -> ProfileView()
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HomeView(language: String) {
    Column {
        Text(
            text = if (language == "en") "Welcome to CNC MASTER" else "CNC MASTER కు స్వాగతం",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 22.sp
        )
        Text(
            text = "Learn. Practice. Become a CNC Expert.",
            color = Color(0xFF00E5FF),
            fontSize = 14.sp
        )
        Spacer(modifier = Modifier.height(16.dp))
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Interactive 3D Lathe Simulator",
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "Simulate spindle rotation, facing, turning & grooving operations.",
                    color = Color(0xFF94A3B8),
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
fun LearnView(language: String) {
    Column {
        Text("9 Progressive CNC Levels", color = Color(0xFF00E5FF), fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text("Bilingual curriculum in English & Telugu", color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable
fun LatheSimulatorView() {
    Column {
        Text("3D Slant-Bed CNC Lathe Simulator", color = Color(0xFF00E5FF), fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text("Virtual machining envelope with rotating chuck, tool turret and DRO readout.", color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable
fun CodeMasterView() {
    Column {
        Text("G-Code & M-Code Encyclopedia", color = Color(0xFF00E5FF), fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text("Searchable ISO codes with syntax, controller differences and warnings.", color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable
fun ProfileView() {
    Column {
        Text("Machinist Profile & Badges", color = Color(0xFF00E5FF), fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Spacer(modifier = Modifier.height(8.dp))
        Text("Designed & Developed by Sai Prakash", color = Color.LightGray, fontSize = 14.sp)
    }
}
